import express from 'express';
import { pool } from '../db.js';

const router = express.Router();

router.get('/', async (_, res) => {
  const { rows } = await pool.query('SELECT * FROM filmes');
  res.json(rows);
});

router.get('/:id', async (req, res) => {
  const { id } = req.params;
  const { rows } = await pool.query('SELECT * FROM filmes WHERE id = $1', [id]);
  rows.length ? res.json(rows[0]) : res.status(404).send('Não encontrado');
});

router.post('/', async (req, res) => {
  const { titulo, diretor, ano, genero } = req.body;
  const result = await pool.query(
    'INSERT INTO filmes (titulo, diretor, ano, genero) VALUES ($1, $2, $3, $4) RETURNING *',
    [titulo, diretor, ano, genero]
  );
  res.status(201).json(result.rows[0]);
});

router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { titulo, diretor, ano, genero } = req.body;
  await pool.query(
    'UPDATE filmes SET titulo=$1, diretor=$2, ano=$3, genero=$4 WHERE id=$5',
    [titulo, diretor, ano, genero, id]
  );
  res.json({ atualizado: id });
});

router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  await pool.query('DELETE FROM filmes WHERE id = $1', [id]);
  res.status(204).end();
});

export default router;
