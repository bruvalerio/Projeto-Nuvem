import express from 'express';
import filmesRouter from './routes/filmes.js'; // ⬅️ Note o .js no final


const app = express();
app.use(express.json());

app.use('/filmes', filmesRouter);

app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000');
});
